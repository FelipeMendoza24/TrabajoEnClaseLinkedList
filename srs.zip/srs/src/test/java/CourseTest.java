import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class CourseTest {
    /**
     * GIVEN contexto
     * WHEN acciones
     * THEN resultado
     */
    @Test
    @DisplayName("GIVEN a course with quota WHEN register a Student THEN should allow")
    public void shouldAllowRegisterAStudent(){

        Student student = new Student(1,"Juan");
        Course course = new Course(1,4,"POO");

        boolean result = course.register(student);
        assertTrue(result, "The student was successfully registered");
    }

    @Test
    @DisplayName("GIVEN a course with the student registered WHEN the same ")
    public void shouldNotAllowRegisterAStudentTwice(){
        Student student1 = new Student(1,"Juan");
        Student student2 = new Student(1,"Juan");
        Course course = new Course(1,4,"POO");

        assertTrue(course.register(student1), "The student was successfully registered");
        assertFalse(course.register(student2), "The student not was successfully registered");
    }
}
