import java.util.ArrayList;

public class Course {

    public static final int MAXIMUM_QUOTA = 30;

    private int id, credits;
    private String name;
    //private Student[] registeredStudents;
    private Course[] preRequirements;
    private list<Student> registeredStudents;

    public Course(int id, int credits, String name) {
        this.id = id;
        this.credits = credits;
        this.name = name;

        registeredStudents = new ArrayList<>();
    }

    public boolean register(Student student){
        boolean result = false;
        boolean exists = false;
        if(MAXIMUM_QUOTA > this.registeredStudents.size()){
            for(int i=0; i < this.registeredStudents.size(); i++){
                if(this.registeredStudents.get(i).equals(student)){
                    exists = true;
                }
            }
        }

        return result;

    }

}
